#!/usr/bin/env python
"""Beamline project"""
from setuptools import setup, find_packages

def readme():
    with open('README.rst') as f:
        return f.read()

setup(
        name         = "beamline",
        version      = "1.1",
        description  = "beamline plot module",
        long_description = "generate plotting for accelerator lattice parsing from MAD-8 lattice definitions.",
        author       = "Tong Zhang",
        author_email = "warriorlance@gmail.com",
        platforms    = ["Linux"],
        license      = "MIT",
        packages = find_packages(),
        #scripts  = ["parse_beamline.py", "elements.py"],
        test_suite = 'nose.collector',
        tests_require = ['nose'],
     )

