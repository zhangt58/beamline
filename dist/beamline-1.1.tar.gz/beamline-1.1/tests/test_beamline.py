#!/usr/bin/env python2

"""
plot beamline from MAD-8 definition file
----
Tong Zhang, Sep.23,2014
"""

import beamline as pbl
import os
latfile = os.path.abspath('./lattice/LPA.list')
beamlinelist = pbl.parse_mad(latfile, 'BL1')
beamlineplot, xlim, ylim = pbl.make_beamline_for_plot(beamlinelist, startpoint=(5, 5))
pbl.plot_lattice(beamlineplot, fig_size = 10, fig_ratio = 0.3, xranges=xlim, yranges=ylim, zoomfac=2)
